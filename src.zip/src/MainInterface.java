import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridLayout;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.*;

public class MainInterface extends HFrame{
	/**
	 *
	 */
	private static final long serialVersionUID = -1395053720340022605L;

	JPanel checkLoginPanel = new JPanel();

	JPanel mainPanel;
	JMenuBar menuBar = new JMenuBar();
	String username;

	LoginInterface LoginFrame = new LoginInterface(this);

	//constructor
	MainInterface(){
		init_Frame();
		init_checkLoginPanel();
		init_mainPanel();

		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	public void run(){
		super.run();
		if(!isLogin()){
			this.remove(mainPanel);
			this.add(checkLoginPanel);
		}
		else{
			username = LoginFrame.username;
			init_mainPanel();
			this.remove(checkLoginPanel);
			this.add(mainPanel);
		}
		this.repaint();
		this.revalidate();
	}

	private void init_menubar() {

		menuBar.add(new JMenu("Doctor"));
		menuBar.add(new JMenu("Patient"));
		menuBar.add(new JMenu("Medicine"));
	}

	private JMenuItem newMenuItem(String text, String className) {
		JMenuItem a = new JMenuItem(text);
		a.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				try {
					Class cls = Class.forName(className);
					HFrame childFrame = (HFrame)cls.newInstance();
					childFrame.run();
				} catch (InstantiationException | IllegalAccessException | ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		return a;
	}

	private void init_Frame(){
		setLayout(null);
		setSize(900, 700);
		setTitle("Hospital Management System");
		init_menubar();
		setJMenuBar(menuBar);
	}
	
	private void init_mainPanel(){
		//UI
		mainPanel = new JPanel();
		mainPanel.setLayout(null);
		JButton logoutButton = new JButton("Logout");
		logoutButton.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
				LoginFrame.Logout();
				run();
			}
		});logoutButton.setBounds(20, 40, 100, 20);

		mainPanel.setBounds(0, 0, 900, 700);
		mainPanel.add(HFrame.newLabel(("Welcome, " + username), new Rectangle(20, 20, 200, 20)));
		mainPanel.add(logoutButton);
		//login time
		String loginTimeString = "Login time: " + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
		mainPanel.add(HFrame.newLabel(loginTimeString, new Rectangle(20, 60, 200, 20)));
	}

	private void init_checkLoginPanel(){

		JLabel loginMessage = new JLabel("Please login");
		loginMessage.setForeground(Color.red);
		checkLoginPanel.add(loginMessage);

		JButton openLoginInterface = new JButton("Login Now");
		openLoginInterface.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
				LoginFrame.run();
			}
		});
		checkLoginPanel.setBounds(400, 300, 100, 300);
		checkLoginPanel.add(openLoginInterface);
	}

	public boolean isLogin(){
		return this.LoginFrame.isLogin;
	}
}