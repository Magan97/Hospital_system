import java.awt.Rectangle;

import javax.swing.JFrame;
import javax.swing.JLabel;

public class HFrame extends JFrame{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	MainInterface mainInterface;

	public static JLabel newLabel(String text, Rectangle r) {
		JLabel a = new JLabel(text);
		a.setBounds(r);
		return a;
	}
	
	//constructor
	HFrame(){
		super();
	}
	HFrame(MainInterface mainInterface){
		super();
		this.mainInterface = mainInterface;
	}

	public void run() {
		this.setVisible(true);
	}
}
