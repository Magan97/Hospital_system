import javax.swing.JFrame;

public class Launcher {
	public static void main(String[] args){
		HFrame a = new MainInterface();
		a.run();
		
		
		//db as = new db();
		//as.asd();
	}
}